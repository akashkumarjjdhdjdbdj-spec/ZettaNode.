import os
import re
import json
import time
import uuid
import sqlite3
import secrets
import string
import asyncio
import subprocess
import shlex
from datetime import datetime, timezone
from typing import Optional

import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

BOT_NAME = os.getenv("BOT_NAME", "ZettaNode Free + Booster VM")
BOT_VERSION = os.getenv("BOT_VERSION", "1.0.0")
BOT_DEVELOPER = os.getenv("BOT_DEVELOPER", "tyrkrox_tech")
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("PREFIX", "free?")
MAIN_ADMIN_ID = int(os.getenv("MAIN_ADMIN_ID", "0") or 0)
BOOSTER_ROLE_ID = int(os.getenv("BOOSTER_ROLE_ID", "0") or 0)
ANNOUNCE_CHANNEL_ID = int(os.getenv("ANNOUNCE_CHANNEL_ID", "0") or 0)
FREE_RAM = int(os.getenv("FREE_RAM_MB", "1024"))
FREE_CPU = float(os.getenv("FREE_CPU", "1"))
FREE_DISK = int(os.getenv("FREE_DISK_GB", "5"))
BOOST_RAM = int(os.getenv("BOOSTER_RAM_MB", "4096"))
BOOST_CPU = float(os.getenv("BOOSTER_CPU", "2"))
BOOST_DISK = int(os.getenv("BOOSTER_DISK_GB", "20"))
MAX_CONTAINERS_PER_USER = int(os.getenv("MAX_CONTAINERS_PER_USER", "1"))
SSH_PORT_START = int(os.getenv("SSH_PORT_START", "22000"))
SSH_PORT_END = int(os.getenv("SSH_PORT_END", "22999"))
DB_PATH = os.getenv("DB_PATH", "zettanode.sqlite3")
IMAGE_NAME = os.getenv("DOCKER_IMAGE", "zettanode-vm:latest")
REQUIRE_DISK_QUOTA = os.getenv("REQUIRE_DISK_QUOTA", "true").lower() == "true"

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS vps (
            id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, guild_id INTEGER NOT NULL,
            container_id TEXT NOT NULL, name TEXT NOT NULL, ram_mb INTEGER NOT NULL,
            cpu REAL NOT NULL, disk_gb INTEGER NOT NULL, ssh_port INTEGER NOT NULL,
            status TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS port_allocations (
            port INTEGER PRIMARY KEY, vps_id TEXT UNIQUE NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS admins (
            user_id INTEGER PRIMARY KEY, added_by INTEGER NOT NULL, added_at TEXT NOT NULL
        )""")

def docker(*args, timeout=120):
    p = subprocess.run(["docker", *map(str, args)], capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or "Docker command failed").strip()[-1500:])
    return p.stdout.strip()

def docker_available():
    try:
        docker("info", "--format", "{{.ServerVersion}}", timeout=15)
        return True, ""
    except Exception as e:
        return False, str(e)

def is_admin(ctx):
    user_id = getattr(ctx.author, "id", 0)
    if user_id == MAIN_ADMIN_ID or getattr(getattr(ctx.author, "guild_permissions", None), "administrator", False):
        return True
    try:
        with db() as con:
            return con.execute("SELECT 1 FROM admins WHERE user_id=?", (user_id,)).fetchone() is not None
    except Exception:
        return False

def is_booster(member):
    if not BOOSTER_ROLE_ID:
        return False
    return any(r.id == BOOSTER_ROLE_ID for r in getattr(member, "roles", []))

def limits_for(member):
    if is_booster(member):
        return BOOST_RAM, BOOST_CPU, BOOST_DISK, "Booster"
    return FREE_RAM, FREE_CPU, FREE_DISK, "Free"

def user_vps(user_id):
    with db() as con:
        return con.execute("SELECT * FROM vps WHERE user_id=? ORDER BY created_at DESC", (user_id,)).fetchall()

def get_vps(vps_id):
    with db() as con:
        return con.execute("SELECT * FROM vps WHERE id=?", (vps_id,)).fetchone()

def allocate_port(vps_id):
    with db() as con:
        used = {r["port"] for r in con.execute("SELECT port FROM port_allocations")}
        for port in range(SSH_PORT_START, SSH_PORT_END + 1):
            if port not in used:
                con.execute("INSERT INTO port_allocations(port,vps_id) VALUES(?,?)", (port, vps_id))
                return port
    raise RuntimeError("No free SSH ports configured. Increase SSH_PORT_START/END.")

def release_port(vps_id):
    with db() as con:
        con.execute("DELETE FROM port_allocations WHERE vps_id=?", (vps_id,))

def random_password(length=18):
    alphabet = string.ascii_letters + string.digits + "!@#%+="
    return "".join(secrets.choice(alphabet) for _ in range(length))

def clean_name(value):
    value = re.sub(r"[^a-zA-Z0-9_.-]", "-", value.lower())[:24].strip("-.")
    return value or "vm"

async def build_container(ctx, ram, cpu, disk, plan):
    ok, err = docker_available()
    if not ok:
        raise RuntimeError(f"Docker is not available: {err}")
    vps_id = uuid.uuid4().hex[:8]
    name = clean_name(f"zn-{ctx.author.id}-{vps_id}")
    port = allocate_port(vps_id)
    password = random_password()
    try:
        # Disk quota is requested explicitly. Docker only enforces this where the
        # storage driver/filesystem supports per-container size limits.
        args = [
            "run", "-d", "--name", name, "--hostname", name,
            "--memory", f"{ram}m", "--memory-swap", f"{ram}m",
            "--cpus", str(cpu), "--pids-limit", "256",
            "--security-opt", "no-new-privileges:true",
            "--cap-drop", "ALL", "--cap-add", "CHOWN", "--cap-add", "SETUID",
            "--cap-add", "SETGID", "--cap-add", "NET_BIND_SERVICE",
            "--cap-add", "DAC_OVERRIDE",
            "--restart", "unless-stopped",
            "-p", f"0.0.0.0:{port}:22",
            "--label", f"zettanode.owner={ctx.author.id}",
            "--label", f"zettanode.vps_id={vps_id}",
            *(["--storage-opt", f"size={disk}G"] if REQUIRE_DISK_QUOTA else []),
            IMAGE_NAME
        ]
        docker(*args, timeout=180)
        # Set a one-time password inside the container; it is never stored in SQLite.
        docker("exec", name, "sh", "-lc",
               "id vmuser >/dev/null 2>&1 || useradd -m -s /bin/bash vmuser")
        docker("exec", name, "sh", "-lc", f"echo 'vmuser:{password}' | chpasswd")
        with db() as con:
            con.execute("""INSERT INTO vps
                (id,user_id,guild_id,container_id,name,ram_mb,cpu,disk_gb,ssh_port,status,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (vps_id, ctx.author.id, ctx.guild.id, name, name, ram, cpu, disk, port,
                 "running", datetime.now(timezone.utc).isoformat()))

        # Public create announcement; credentials are never posted here.
        if ANNOUNCE_CHANNEL_ID:
            channel = bot.get_channel(ANNOUNCE_CHANNEL_ID)
            if channel is None:
                try:
                    channel = await bot.fetch_channel(ANNOUNCE_CHANNEL_ID)
                except Exception:
                    channel = None
            if channel is not None:
                announce = discord.Embed(
                    title="🚀 New VPS Created",
                    description=f"A new **{plan}** VPS has been provisioned.",
                    color=0x2ECC71,
                    timestamp=datetime.now(timezone.utc)
                )
                announce.add_field(name="User", value=ctx.author.mention, inline=True)
                announce.add_field(name="VPS ID", value=f"`{vps_id}`", inline=True)
                announce.add_field(name="Resources", value=f"RAM: **{ram} MB**\nCPU limit: **{cpu}**\nDisk quota: **{disk} GB**", inline=False)
                announce.add_field(name="Status", value="🟢 Running", inline=True)
                announce.set_footer(text=f"{BOT_NAME} • {BOT_DEVELOPER}")
                try:
                    await channel.send(embed=announce)
                except Exception:
                    pass
        return vps_id, name, port, password
    except Exception:
        try:
            docker("rm", "-f", name, timeout=30)
        except Exception:
            pass
        release_port(vps_id)
        raise

async def owner_or_admin(ctx, row):
    return is_admin(ctx) or row["user_id"] == ctx.author.id

@bot.event
async def on_ready():
    init_db()
    print(f"{BOT_NAME} online as {bot.user} | prefix={PREFIX}")


class VPSManageView(discord.ui.View):
    def __init__(self, vps_id: str):
        super().__init__(timeout=300)
        self.vps_id = vps_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        row = get_vps(self.vps_id)
        if not row:
            await interaction.response.send_message("VPS not found.", ephemeral=True)
            return False
        allowed = interaction.user.id == row["user_id"] or interaction.user.id == MAIN_ADMIN_ID
        if not allowed and isinstance(interaction.user, discord.Member):
            allowed = interaction.user.guild_permissions.administrator
        if not allowed:
            await interaction.response.send_message("You do not own this VPS.", ephemeral=True)
        return allowed

    @discord.ui.button(label="SSH Details", style=discord.ButtonStyle.primary, emoji="🔐")
    async def ssh_details(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = get_vps(self.vps_id)
        host = os.getenv("PUBLIC_IP", "YOUR_SERVER_PUBLIC_IP")
        await interaction.response.send_message(
            f"**SSH connection**\\n`ssh vmuser@{host} -p {row['ssh_port']}`\\n"
            "Username: `vmuser`\\nYour password was sent to your DMs when the VPS was created.",
            ephemeral=True
        )

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, emoji="▶️")
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        row = get_vps(self.vps_id)
        try:
            docker("start", row["container_id"])
            with db() as con:
                con.execute("UPDATE vps SET status='running' WHERE id=?", (self.vps_id,))
            await interaction.followup.send("VPS started.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Start failed: `{str(e)[:800]}`", ephemeral=True)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger, emoji="⏹️")
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        row = get_vps(self.vps_id)
        try:
            docker("stop", row["container_id"])
            with db() as con:
                con.execute("UPDATE vps SET status='stopped' WHERE id=?", (self.vps_id,))
            await interaction.followup.send("VPS stopped.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Stop failed: `{str(e)[:800]}`", ephemeral=True)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.secondary, emoji="🔄")
    async def restart_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        row = get_vps(self.vps_id)
        try:
            docker("restart", row["container_id"])
            with db() as con:
                con.execute("UPDATE vps SET status='running' WHERE id=?", (self.vps_id,))
            await interaction.followup.send("VPS restarted.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Restart failed: `{str(e)[:800]}`", ephemeral=True)

    @discord.ui.button(label="Change Password", style=discord.ButtonStyle.primary, emoji="🔑")
    async def password_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ChangePasswordModal(self.vps_id))

    @discord.ui.button(label="Bash", style=discord.ButtonStyle.secondary, emoji="💻")
    async def bash_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(BashModal(self.vps_id))

    @discord.ui.button(label="SSHX Guide", style=discord.ButtonStyle.secondary, emoji="🌐")
    async def sshx_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = get_vps(self.vps_id)
        host = os.getenv("PUBLIC_IP", "YOUR_SERVER_PUBLIC_IP")
        await interaction.response.send_message(
            "**SSHX access**\\n"
            f"First connect to your container: `ssh vmuser@{host} -p {row['ssh_port']}`\\n"
            "Then run `sshx` if the SSHX CLI is installed in that container. "
            "This bot does not create or publish an SSHX sharing URL automatically.",
            ephemeral=True
        )


class ChangePasswordModal(discord.ui.Modal, title="Change VPS Password"):
    password = discord.ui.TextInput(label="New password", min_length=12, max_length=64, required=True)

    def __init__(self, vps_id: str):
        super().__init__()
        self.vps_id = vps_id

    async def on_submit(self, interaction: discord.Interaction):
        row = get_vps(self.vps_id)
        if not row or (interaction.user.id != row["user_id"] and interaction.user.id != MAIN_ADMIN_ID
                       and not (isinstance(interaction.user, discord.Member) and interaction.user.guild_permissions.administrator)):
            return await interaction.response.send_message("Not authorized.", ephemeral=True)
        try:
            # Pass password via stdin to avoid putting it in the shell command line.
            proc = subprocess.run(
                ["docker", "exec", "-i", row["container_id"], "chpasswd"],
                input=f"vmuser:{self.password.value}\\n", text=True, capture_output=True, timeout=30
            )
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr[-700:])
            await interaction.response.send_message("Password changed successfully.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Password change failed: `{str(e)[:700]}`", ephemeral=True)


class BashModal(discord.ui.Modal, title="Run command in your VPS"):
    command = discord.ui.TextInput(label="Bash command", style=discord.TextStyle.paragraph,
                                   placeholder="e.g. uname -a", max_length=1000, required=True)

    def __init__(self, vps_id: str):
        super().__init__()
        self.vps_id = vps_id

    async def on_submit(self, interaction: discord.Interaction):
        row = get_vps(self.vps_id)
        allowed = row and (interaction.user.id == row["user_id"] or interaction.user.id == MAIN_ADMIN_ID
                           or (isinstance(interaction.user, discord.Member) and interaction.user.guild_permissions.administrator))
        if not allowed:
            return await interaction.response.send_message("Not authorized.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            output = docker("exec", row["container_id"], "bash", "-lc", self.command.value, timeout=30)
            output = output[-1600:] if output else "(command completed with no output)"
            await interaction.followup.send(f"```text\\n{output}\\n```", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Command failed: `{str(e)[:1000]}`", ephemeral=True)


@bot.command(name="manage")
async def manage_cmd(ctx, vps_id: str):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VPS not found or you don't have permission.")
    embed = discord.Embed(title=f"Manage VPS • {vps_id}", color=0x5865F2)
    embed.description = (
        f"**Status:** `{row['status']}`\\n"
        f"**RAM:** {row['ram_mb']} MB • **CPU:** {row['cpu']} • **Disk:** {row['disk_gb']} GB\\n"
        f"Choose an action below. Buttons are private to the VPS owner/admin."
    )
    await ctx.reply(embed=embed, view=VPSManageView(vps_id), mention_author=False)


@bot.command(name="ssh")
async def ssh_cmd(ctx, vps_id: str):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VPS not found or you don't have permission.")
    host = os.getenv("PUBLIC_IP", "YOUR_SERVER_PUBLIC_IP")
    await ctx.author.send(f"SSH: `ssh vmuser@{host} -p {row['ssh_port']}`\\nUsername: `vmuser`")
    await ctx.reply("SSH details sent to your DM.", mention_author=False)


@bot.command(name="sshx")
async def sshx_cmd(ctx, vps_id: str):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VPS not found or you don't have permission.")
    host = os.getenv("PUBLIC_IP", "YOUR_SERVER_PUBLIC_IP")
    await ctx.author.send(
        f"Connect first: `ssh vmuser@{host} -p {row['ssh_port']}`\\n"
        "Then run `sshx` if you have installed the SSHX CLI. "
        "The bot cannot generate a share URL unless SSHX is installed and configured in the container."
    )
    await ctx.reply("SSHX connection instructions sent to your DM.", mention_author=False)


@bot.command(name="help")
async def help_cmd(ctx):
    e = discord.Embed(title=BOT_NAME, description=f"Prefix: `{PREFIX}`", color=0x5865F2)
    e.add_field(name="User commands", value=(
        f"`{PREFIX}create` — create your plan VM\n"
        f"`{PREFIX}vps` — list your VMs\n"
        f"`{PREFIX}info <id>` — VM details\n"
        f"`{PREFIX}start <id>` / `{PREFIX}stop <id>` / `{PREFIX}restart <id>`\n"
        f"`{PREFIX}delete <id>` — delete your VM\n"
        f"`{PREFIX}manage <id>` — interactive manage panel\n"
        f"`{PREFIX}ssh <id>` / `{PREFIX}sshx <id>` — connection help"
    ), inline=False)
    e.add_field(name="Admin commands", value=(
        f"`{PREFIX}admin list`\n"
        f"`{PREFIX}admin create <user_id> <ram_mb> <cpu> <disk_gb>`\n"
        f"`{PREFIX}admin suspend <id>` / `{PREFIX}admin unsuspend <id>`\n"
        f"`{PREFIX}admin delete <id>`"
    ), inline=False)
    e.set_footer(text=f"Made by {BOT_DEVELOPER} • Containers are not KVM virtual machines")
    await ctx.reply(embed=e, mention_author=False)

@bot.command(name="create")
@commands.guild_only()
async def create_cmd(ctx):
    existing = user_vps(ctx.author.id)
    if len(existing) >= MAX_CONTAINERS_PER_USER:
        return await ctx.reply(f"You already have the maximum ({MAX_CONTAINERS_PER_USER}) VM(s).")
    ram, cpu, disk, plan = limits_for(ctx.author)
    msg = await ctx.reply(f"Creating your **{plan}** VM with {ram} MB RAM, {cpu} CPU limit and {disk} GB requested disk quota...")
    try:
        vps_id, name, port, password = await build_container(ctx, ram, cpu, disk, plan)
        try:
            await ctx.author.send(
                f"**{BOT_NAME} — VM credentials**\n"
                f"VM ID: `{vps_id}`\nHost: `{os.getenv('PUBLIC_IP', 'YOUR_SERVER_PUBLIC_IP')}`\n"
                f"SSH port: `{port}`\nUsername: `vmuser`\nPassword: `{password}`\n"
                f"RAM: `{ram} MB` • CPU limit: `{cpu}` • Requested disk quota: `{disk} GB`\n"
                "Change this password immediately after login. Do not share these credentials."
            )
            await msg.edit(content=f"VM created successfully. ID: `{vps_id}`. SSH credentials were sent to your DM.")
        except discord.Forbidden:
            await msg.edit(content="VM created, but I could not DM you. Enable DMs and contact an admin to arrange a credential reset.")
    except Exception as e:
        await msg.edit(content=f"VM creation failed: `{str(e)[:1200]}`")

@bot.command(name="vps")
async def vps_cmd(ctx):
    rows = user_vps(ctx.author.id)
    if not rows:
        return await ctx.reply("You don't have any VMs yet.")
    lines = [f"`{r['id']}` • **{r['status']}** • {r['ram_mb']} MB / {r['cpu']} CPU / {r['disk_gb']} GB • SSH `{r['ssh_port']}`" for r in rows]
    await ctx.reply(embed=discord.Embed(title="Your ZettaNode VMs", description="\n".join(lines), color=0x5865F2))

@bot.command(name="info")
async def info_cmd(ctx, vps_id: str):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VM not found or you don't have permission.")
    try:
        state = json.loads(docker("inspect", row["container_id"]))[0]["State"]
        status = state.get("Status", "unknown")
    except Exception:
        status = "unknown"
    e = discord.Embed(title=f"VM {row['id']}", color=0x5865F2)
    e.add_field(name="Status", value=status)
    e.add_field(name="Resources", value=f"RAM: {row['ram_mb']} MB\nCPU limit: {row['cpu']}\nDisk quota request: {row['disk_gb']} GB")
    e.add_field(name="SSH", value=f"Port: {row['ssh_port']}\nUsername: vmuser")
    await ctx.reply(embed=e)

async def lifecycle(ctx, vps_id, action):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VM not found or you don't have permission.")
    try:
        docker(action, row["container_id"])
        with db() as con:
            con.execute("UPDATE vps SET status=? WHERE id=?", ({"start":"running","stop":"stopped","restart":"running"}[action], vps_id))
        await ctx.reply(f"VM `{vps_id}` {action} successful.")
    except Exception as e:
        await ctx.reply(f"Failed: `{str(e)[:900]}`")

@bot.command(name="start")
async def start_cmd(ctx, vps_id: str): await lifecycle(ctx, vps_id, "start")
@bot.command(name="stop")
async def stop_cmd(ctx, vps_id: str): await lifecycle(ctx, vps_id, "stop")
@bot.command(name="restart")
async def restart_cmd(ctx, vps_id: str): await lifecycle(ctx, vps_id, "restart")

async def delete_vps(ctx, vps_id):
    row = get_vps(vps_id)
    if not row or not await owner_or_admin(ctx, row):
        return await ctx.reply("VM not found or you don't have permission.")
    try:
        docker("rm", "-f", row["container_id"])
        with db() as con:
            con.execute("DELETE FROM vps WHERE id=?", (vps_id,))
        release_port(vps_id)
        await ctx.reply(f"VM `{vps_id}` deleted.")
    except Exception as e:
        await ctx.reply(f"Delete failed: `{str(e)[:900]}`")

@bot.command(name="delete")
async def delete_cmd(ctx, vps_id: str): await delete_vps(ctx, vps_id)

@bot.group(name="admin", invoke_without_command=True)
async def admin_group(ctx):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    await ctx.invoke(help_cmd)

@admin_group.command(name="add")
async def admin_add(ctx, member: discord.Member):
    if not is_admin(ctx):
        return await ctx.reply("Admin only.")
    if member.id == MAIN_ADMIN_ID:
        return await ctx.reply("This user is already the main admin.")
    with db() as con:
        con.execute(
            "INSERT OR IGNORE INTO admins(user_id,added_by,added_at) VALUES(?,?,?)",
            (member.id, ctx.author.id, datetime.now(timezone.utc).isoformat())
        )
    await ctx.reply(f"✅ {member.mention} is now a ZettaNode bot admin.")

@admin_group.command(name="remove")
async def admin_remove(ctx, member: discord.Member):
    if not is_admin(ctx):
        return await ctx.reply("Admin only.")
    if member.id == MAIN_ADMIN_ID:
        return await ctx.reply("The main admin cannot be removed with this command.")
    with db() as con:
        cur = con.execute("DELETE FROM admins WHERE user_id=?", (member.id,))
    if cur.rowcount:
        await ctx.reply(f"✅ Removed {member.mention} from ZettaNode bot admins.")
    else:
        await ctx.reply("That user is not an added bot admin.")

@admin_group.command(name="admins")
async def admin_show(ctx):
    if not is_admin(ctx):
        return await ctx.reply("Admin only.")
    with db() as con:
        rows = con.execute("SELECT user_id FROM admins ORDER BY added_at").fetchall()
    lines = [f"<@{MAIN_ADMIN_ID}> — Main Admin"] if MAIN_ADMIN_ID else []
    lines += [f"<@{r['user_id']}>" for r in rows]
    await ctx.reply("**ZettaNode Admins**\\n" + ("\\n".join(lines) if lines else "No admins configured."))

@admin_group.command(name="list")
async def admin_list(ctx):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    with db() as con:
        rows = con.execute("SELECT * FROM vps ORDER BY created_at DESC LIMIT 30").fetchall()
    if not rows: return await ctx.reply("No VMs found.")
    lines = [f"`{r['id']}` • user `{r['user_id']}` • {r['status']} • {r['ram_mb']}MB/{r['cpu']}CPU/{r['disk_gb']}GB" for r in rows]
    await ctx.reply("\n".join(lines))

@admin_group.command(name="create")
async def admin_create(ctx, user_id: int, ram_mb: int, cpu: float, disk_gb: int):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    if ram_mb < 256 or ram_mb > 65536 or cpu <= 0 or cpu > 32 or disk_gb < 1 or disk_gb > 500:
        return await ctx.reply("Limits: RAM 256–65536 MB, CPU >0–32, disk 1–500 GB.")
    member = ctx.guild.get_member(user_id)
    if member is None:
        try: member = await ctx.guild.fetch_member(user_id)
        except Exception: return await ctx.reply("User is not a member of this server.")
    class AdminCtx:
        author = member
        guild = ctx.guild
    try:
        vps_id, name, port, password = await build_container(AdminCtx(), ram_mb, cpu, disk_gb, "Admin")
        await ctx.reply(f"Created `{vps_id}` for <@{user_id}>. SSH port `{port}`.")
        try:
            await member.send(f"Your VM was provisioned by an admin.\nID: `{vps_id}`\nHost: `{os.getenv('PUBLIC_IP','YOUR_SERVER_PUBLIC_IP')}`\nPort: `{port}`\nUser: `vmuser`\nPassword: `{password}`")
        except discord.Forbidden: pass
    except Exception as e:
        await ctx.reply(f"Create failed: `{str(e)[:1000]}`")

@admin_group.command(name="suspend")
async def admin_suspend(ctx, vps_id: str):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    row = get_vps(vps_id)
    if not row: return await ctx.reply("VM not found.")
    try:
        docker("pause", row["container_id"])
        with db() as con: con.execute("UPDATE vps SET status='suspended' WHERE id=?", (vps_id,))
        await ctx.reply(f"Suspended `{vps_id}`.")
    except Exception as e: await ctx.reply(f"Failed: `{str(e)[:900]}`")

@admin_group.command(name="unsuspend")
async def admin_unsuspend(ctx, vps_id: str):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    row = get_vps(vps_id)
    if not row: return await ctx.reply("VM not found.")
    try:
        docker("unpause", row["container_id"])
        with db() as con: con.execute("UPDATE vps SET status='running' WHERE id=?", (vps_id,))
        await ctx.reply(f"Unsuspended `{vps_id}`.")
    except Exception as e: await ctx.reply(f"Failed: `{str(e)[:900]}`")

@admin_group.command(name="delete")
async def admin_delete(ctx, vps_id: str):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    row = get_vps(vps_id)
    if not row: return await ctx.reply("VM not found.")
    try:
        docker("rm", "-f", row["container_id"])
        with db() as con: con.execute("DELETE FROM vps WHERE id=?", (vps_id,))
        release_port(vps_id)
        await ctx.reply(f"Deleted `{vps_id}`.")
    except Exception as e: await ctx.reply(f"Delete failed: `{str(e)[:900]}`")

@bot.command(name="health")
async def health_cmd(ctx):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    try:
        version = docker("info", "--format", "{{.ServerVersion}}", timeout=15)
        usage = docker("system", "df", "--format", "{{json .}}")
        await ctx.reply(f"Docker: `{version}`\nStorage: `{usage[:1200]}`")
    except Exception as e: await ctx.reply(f"Docker health check failed: `{str(e)[:900]}`")

if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN missing. Put your bot token in .env")
    init_db()
    bot.run(TOKEN)
