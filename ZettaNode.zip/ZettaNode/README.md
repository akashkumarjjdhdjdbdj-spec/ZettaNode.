# ZettaNode Free + Booster VM

A Discord prefix bot that provisions **Docker-based Linux containers** with RAM and CPU limits, lifecycle controls, SQLite records, and SSH access.

## Important
This creates isolated Linux containers, **not KVM virtual machines**. Docker CPU is a quota/ceiling, not dedicated physical cores. Memory is enforced by Docker. Disk quota is requested using Docker `--storage-opt size=...G`; enforcement depends on the Docker storage driver and backing filesystem (commonly XFS with project quotas). Keep `REQUIRE_DISK_QUOTA=true` if you require a hard quota: container creation should fail rather than silently pretending a quota exists.

The bot deliberately does not use `--privileged`, host mounts, host networking, or the Docker socket inside user containers. Run it on a VPS you own/administer.

## Install
1. Upload and extract this folder on the Docker host.
2. Ensure Docker Engine and Python 3 are installed and `docker info` works.
3. Run `cp .env.example .env`, then edit `.env`.
4. Put a **new** Discord bot token in `.env` (never post it in chat). If an old token was exposed, regenerate it in Discord Developer Portal.
5. Set `MAIN_ADMIN_ID`, `BOOSTER_ROLE_ID`, and `PUBLIC_IP`.
6. Enable **Message Content Intent** and **Server Members Intent** for the bot in Discord Developer Portal.
7. Run `chmod +x install.sh && ./install.sh`.
8. Start: `source .venv/bin/activate && python bot.py`.

The bot process needs access to Docker. For a production setup, use a dedicated service account and carefully grant Docker access; membership in the `docker` group is effectively root-level access on the host.

## Commands (default prefix `free?`)
- `free?help`
- `free?create`
- `free?vps`
- `free?info <id>`
- `free?start <id>`
- `free?stop <id>`
- `free?restart <id>`
- `free?delete <id>`
- `free?admin list`
- `free?admin create <user_id> <ram_mb> <cpu> <disk_gb>`
- `free?admin suspend <id>`
- `free?admin unsuspend <id>`
- `free?admin delete <id>`
- `free?health`

## Resource configuration
Edit `.env`:
- Free defaults: 1024 MB RAM, 1 CPU quota, 5 GB requested disk quota.
- Booster defaults: 4096 MB RAM, 2 CPU quota, 20 GB requested disk quota.
- `BOOSTER_ROLE_ID` must be the actual server booster role ID.
- `SSH_PORT_START` and `SSH_PORT_END` define the host port range mapped to container port 22.
- Open that TCP port range in your VPS firewall/security group.

## Notes
- Credentials are DM-only and passwords are not stored in SQLite.
- Each user gets one container by default. Change `MAX_CONTAINERS_PER_USER` if needed.
- This starter version does not include a web panel, backup system, billing, or reinstall command.
- Do not expose the Discord bot token or user VM credentials.

## Create announcements and Manage panel
Set `ANNOUNCE_CHANNEL_ID` in `.env` to the Discord channel ID where successful VPS creation embeds should be posted. The announcement contains the member, VPS ID, plan resources and status; it never includes credentials.

Run `free?manage <vps_id>` to open the interactive control panel. Bash commands execute **inside that user's container only** and are owner/admin gated. SSHX button provides connection guidance; an SSHX share URL is not auto-created unless you separately install and configure the SSHX CLI in the container.
