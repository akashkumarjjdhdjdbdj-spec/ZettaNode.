import os, re, aiohttp, discord
from discord.ext import commands

PANEL = os.environ["PANEL_URL"].rstrip("/")
KEY = os.environ["PANEL_API_KEY"]
TOKEN = os.environ["DISCORD_TOKEN"]

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="free?", intents=intents, help_command=None)


async def api(method, path, data=None):
    async with aiohttp.ClientSession(headers={"X-API-Key": KEY}) as s:
        async with s.request(method, PANEL + path, json=data) as r:
            return await r.json()


def ident(text):
    m = re.fullmatch(r"<@!?(\d+)>", text.strip())
    return (m.group(1) if m else text.strip().lstrip("@")).lower()


async def is_admin(ctx):
    res = await api("GET", "/api/admins")
    ids = res.get("admins", [])
    return str(ctx.author.id) in ids or ctx.author.name.lower() in ids


@bot.check
async def only_admins(ctx):
    return await is_admin(ctx)


def reply(res, ok_msg):
    return ("✅ " + ok_msg) if res.get("ok") else ("❌ " + str(res.get("error")))


@bot.command(name="create")
async def create(ctx, ram: float, cpu: float, disk: float, os_name: str, username: str):
    res = await api("POST", "/api/create", dict(ram=ram, cpu=cpu, disk=disk, os=os_name, username=username))
    await ctx.send(reply(res, f"VPS is being created for panel user `{username}`. Check the panel."))


@bot.command(name="vps-delete")
async def vps_delete(ctx, username: str, vps_id: str = None):
    res = await api("POST", "/api/delete", dict(username=username, id=vps_id))
    await ctx.send(reply(res, f"VPS of `{username}` deleted."))


@bot.command(name="vps-suspend")
async def vps_suspend(ctx, username: str, vps_id: str = None):
    res = await api("POST", "/api/suspend", dict(username=username, id=vps_id))
    state = "suspended" if res.get("suspended") else "unsuspended"
    await ctx.send(reply(res, f"VPS of `{username}` {state}."))


@bot.command(name="add-admin")
async def add_admin(ctx, who: str):
    await api("POST", "/api/admins", dict(ident=ident(who)))
    await ctx.send(f"✅ `{who}` is now a bot admin.")


@bot.command(name="remove-admin")
async def remove_admin(ctx, who: str):
    await api("DELETE", "/api/admins", dict(ident=ident(who)))
    await ctx.send(f"✅ `{who}` removed from bot admins.")


@bot.event
async def on_command_error(ctx, err):
    if isinstance(err, commands.CheckFailure) or isinstance(err, commands.CommandNotFound):
        return
    if isinstance(err, (commands.MissingRequiredArgument, commands.BadArgument)):
        await ctx.send("❌ Wrong usage.\n`free?create <ram_gb> <cpu> <disk_gb> <os> <panel_username>`\n"
                       "`free?vps-delete <panel_username> [vps_id]`\n`free?vps-suspend <panel_username> [vps_id]`\n"
                       "`free?add-admin <discord_user>` · `free?remove-admin <discord_user>`")
        return
    await ctx.send(f"❌ {err}")


@bot.event
async def on_ready():
    print(f"ZettaNode bot online as {bot.user}")


bot.run(TOKEN)
