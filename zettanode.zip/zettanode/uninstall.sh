#!/bin/bash
# ZettaNode uninstaller
[ "$EUID" -ne 0 ] && echo "Run as root: bash uninstall.sh" && exit 1
read -rp "This removes the panel AND all zn-* VPS containers. Type YES: " a
[ "$a" != "YES" ] && echo "Cancelled." && exit 0
pkill -f /opt/zettanode/app.py 2>/dev/null
pkill -f /opt/zettanode/bot.py 2>/dev/null
if [ -d /run/systemd/system ]; then
  systemctl disable --now zettanode 2>/dev/null
  rm -f /etc/systemd/system/zettanode.service
  systemctl daemon-reload
fi
docker ps -a --format '{{.Names}}' 2>/dev/null | grep '^zn-' | xargs -r docker rm -f
rm -rf /opt/zettanode
echo "✅ ZettaNode removed."
