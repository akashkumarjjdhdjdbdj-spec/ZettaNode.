#!/bin/bash
# ZettaNode uninstaller
[ "$EUID" -ne 0 ] && echo "Run as root: sudo bash uninstall.sh" && exit 1
read -rp "This removes the panel AND all zn-* VPS containers. Type YES: " a
[ "$a" != "YES" ] && echo "Cancelled." && exit 0
systemctl disable --now zettanode 2>/dev/null
rm -f /etc/systemd/system/zettanode.service
systemctl daemon-reload
docker ps -a --format '{{.Names}}' | grep '^zn-' | xargs -r docker rm -f
rm -rf /opt/zettanode
echo "✅ ZettaNode removed."
