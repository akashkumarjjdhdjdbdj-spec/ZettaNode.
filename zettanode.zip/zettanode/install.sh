#!/bin/bash
# ZettaNode installer
set -e
[ "$EUID" -ne 0 ] && echo "Run as root: sudo bash install.sh" && exit 1

read -rp "Panel name [ZettaNode]: " PANEL_NAME; PANEL_NAME=${PANEL_NAME:-ZettaNode}
read -rp "Panel port [8090]: " PORT; PORT=${PORT:-8090}
DIR=/opt/zettanode
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "[1/5] Installing dependencies..."
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip curl >/dev/null
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
systemctl enable --now docker 2>/dev/null || true

echo "[2/5] Copying files to $DIR..."
mkdir -p $DIR
cp "$SRC/app.py" "$SRC/bot.py" "$SRC/uninstall.sh" $DIR/

echo "[3/5] Python environment..."
python3 -m venv $DIR/venv
$DIR/venv/bin/pip install -q flask "discord.py" aiohttp

echo "[4/5] Writing config..."
cat > $DIR/.env <<ENV
PANEL_NAME=$PANEL_NAME
PORT=$PORT
SECRET_KEY=$(head -c 32 /dev/urandom | base64 | tr -dc A-Za-z0-9)
ENV

echo "[5/5] Creating service..."
cat > /etc/systemd/system/zettanode.service <<UNIT
[Unit]
Description=$PANEL_NAME panel
After=network.target docker.service

[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python $DIR/app.py
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now zettanode

echo
echo "✅ $PANEL_NAME installed -> http://localhost:$PORT"
echo "First registered user becomes admin. Then open Admin > API & Bot."
