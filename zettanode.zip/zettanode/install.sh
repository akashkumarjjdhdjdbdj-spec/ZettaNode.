#!/bin/bash
# ZettaNode installer (works with or without systemd)
[ "$EUID" -ne 0 ] && echo "Run as root: bash install.sh" && exit 1

read -rp "Panel name [ZettaNode]: " PANEL_NAME; PANEL_NAME=${PANEL_NAME:-ZettaNode}
read -rp "Panel port [8090]: " PORT; PORT=${PORT:-8090}
DIR=/opt/zettanode
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "[1/5] Installing dependencies..."
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip curl >/dev/null
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh

echo "[2/5] Copying files to $DIR..."
mkdir -p $DIR
cp "$SRC/app.py" "$SRC/bot.py" "$SRC/uninstall.sh" $DIR/

echo "[3/5] Python environment..."
python3 -m venv $DIR/venv
$DIR/venv/bin/pip install -q flask "discord.py" aiohttp

echo "[4/5] Writing config..."
cat > $DIR/.env <<ENV
PANEL_NAME=$PANEL_NAME
PORT=$PORT
SECRET_KEY=$(head -c 32 /dev/urandom | base64 | tr -dc A-Za-z0-9)
ENV

# helper scripts (used when systemd is not available)
cat > $DIR/start.sh <<'S'
#!/bin/bash
cd /opt/zettanode
pkill -f "/opt/zettanode/app.py" 2>/dev/null
if ! docker info >/dev/null 2>&1; then
  nohup dockerd > /var/log/dockerd.log 2>&1 &
  sleep 6
fi
nohup /opt/zettanode/venv/bin/python /opt/zettanode/app.py > /opt/zettanode/panel.log 2>&1 &
echo "ZettaNode started. Log: /opt/zettanode/panel.log"
S
cat > $DIR/stop.sh <<'S'
#!/bin/bash
pkill -f "/opt/zettanode/app.py" && echo "ZettaNode stopped."
S
chmod +x $DIR/start.sh $DIR/stop.sh

echo "[5/5] Starting panel..."
if [ -d /run/systemd/system ] && command -v systemctl >/dev/null; then
  cat > /etc/systemd/system/zettanode.service <<UNIT
[Unit]
Description=$PANEL_NAME panel
After=network.target docker.service

[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/python $DIR/app.py
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now docker 2>/dev/null
  systemctl enable --now zettanode
  echo "Mode: systemd (sudo systemctl restart zettanode)"
else
  bash $DIR/start.sh
  echo "Mode: no systemd (restart: bash $DIR/start.sh | stop: bash $DIR/stop.sh)"
fi

sleep 3
docker info >/dev/null 2>&1 && echo "Docker: OK" || echo "WARNING: Docker daemon is not running here. VPS creation will fail (see notes)."
echo
echo "✅ $PANEL_NAME installed -> http://localhost:$PORT"
echo "First registered user becomes admin. Then open Admin Panel."
