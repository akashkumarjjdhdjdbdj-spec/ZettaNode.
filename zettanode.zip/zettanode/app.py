import os, re, sys, time, sqlite3, secrets, subprocess, threading
from functools import wraps
from flask import (Flask, request, session, redirect, url_for, jsonify, g,
                   abort, flash, render_template)
from jinja2 import DictLoader
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "zettanode.db")


def load_env():
    d = {}
    p = os.path.join(BASE, ".env")
    if os.path.exists(p):
        for l in open(p):
            if "=" in l and not l.startswith("#"):
                k, v = l.strip().split("=", 1)
                d[k] = v
    return d


ENV = load_env()
PANEL_NAME = ENV.get("PANEL_NAME", "ZettaNode")
PORT = int(ENV.get("PORT", "8090"))

app = Flask(__name__)
app.secret_key = ENV.get("SECRET_KEY", "change-me")

OS_IMAGES = {
    "ubuntu": "ubuntu:24.04", "ubuntu24": "ubuntu:24.04", "ubuntu22": "ubuntu:22.04",
    "debian": "debian:12", "debian12": "debian:12", "alpine": "alpine:3.20",
}

# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, pw TEXT, is_admin INT DEFAULT 0, created INT);
CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY, user_id INT, name TEXT, ram REAL, cpu REAL, disk REAL, os TEXT,
  status TEXT DEFAULT 'installing', suspended INT DEFAULT 0, root_pw TEXT, sshx TEXT, created INT);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS bot_admins(ident TEXT PRIMARY KEY);
"""


def dbc():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def db():
    if "db" not in g:
        g.db = dbc()
    return g.db


@app.teardown_appcontext
def close_db(_):
    c = g.pop("db", None)
    if c:
        c.close()


def init_db():
    c = dbc()
    c.executescript(SCHEMA)
    if not c.execute("SELECT v FROM settings WHERE k='api_key'").fetchone():
        c.execute("INSERT INTO settings VALUES('api_key',?)", ("zn_" + secrets.token_hex(24),))
    c.commit()
    c.close()


def setting(k, d=""):
    r = db().execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
    return r["v"] if r else d


def set_setting(k, v):
    db().execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, v))
    db().commit()


# ---------------------------------------------------------------- docker
def sh(args, timeout=120):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).strip()
    except Exception as e:
        return 1, str(e)


def cname(vid):
    return f"zn-{vid}"


def running(vid):
    rc, out = sh(["docker", "inspect", "-f", "{{.State.Running}}", cname(vid)], 15)
    return rc == 0 and out.strip() == "true"


def provision(vid):
    c = dbc()
    v = c.execute("SELECT * FROM vps WHERE id=?", (vid,)).fetchone()
    name, img = cname(vid), OS_IMAGES[v["os"]]
    pw = secrets.token_urlsafe(9)
    sh(["docker", "rm", "-f", name], 30)
    base = ["docker", "run", "-d", "--name", name, "--hostname", v["name"],
            "--memory", f"{int(v['ram'] * 1024)}m", "--memory-swap", f"{int(v['ram'] * 1024)}m",
            "--cpus", str(v["cpu"]), "--restart", "unless-stopped"]
    rc, out = sh(base + ["--storage-opt", f"size={int(v['disk'])}g", img, "sleep", "infinity"], 600)
    if rc:  # storage driver without quota support -> retry without disk limit
        rc, out = sh(base + [img, "sleep", "infinity"], 600)
    if rc:
        c.execute("UPDATE vps SET status='error' WHERE id=?", (vid,))
        c.commit()
        return
    if v["os"] == "alpine":
        script = f"apk add -q curl sudo nano procps bash; echo root:{pw} | chpasswd"
    else:
        script = ("export DEBIAN_FRONTEND=noninteractive; apt-get update -qq; "
                  "apt-get install -y -qq curl sudo nano procps iputils-ping net-tools >/dev/null; "
                  f"echo root:{pw} | chpasswd")
    sh(["docker", "exec", name, "sh", "-c", script], 900)
    c.execute("UPDATE vps SET status='ready', root_pw=?, sshx=NULL WHERE id=?", (pw, vid))
    c.commit()
    c.close()


def create_vps(user_id, ram, cpu, disk, osk):
    osk = osk.lower()
    if osk not in OS_IMAGES:
        return None, "OS not supported. Use: " + ", ".join(OS_IMAGES)
    if not (0.25 <= ram <= 256 and 0.1 <= cpu <= 64 and 1 <= disk <= 2000):
        return None, "Invalid ram/cpu/disk values."
    cur = db().execute(
        "INSERT INTO vps(user_id,name,ram,cpu,disk,os,created) VALUES(?,?,?,?,?,?,?)",
        (user_id, "", ram, cpu, disk, osk, int(time.time())))
    db().commit()
    vid = cur.lastrowid
    db().execute("UPDATE vps SET name=? WHERE id=?", (f"ZettaNode-free-vps-{secrets.token_hex(3)}", vid))
    db().commit()
    threading.Thread(target=provision, args=(vid,), daemon=True).start()
    return vid, None


def destroy_vps(vid):
    sh(["docker", "rm", "-f", cname(vid)], 60)
    db().execute("DELETE FROM vps WHERE id=?", (vid,))
    db().commit()


# ---------------------------------------------------------------- bot process
BOT = {"proc": None}


def bot_running():
    return BOT["proc"] is not None and BOT["proc"].poll() is None


def bot_start():
    if bot_running():
        return
    env = dict(os.environ, PANEL_URL=f"http://127.0.0.1:{PORT}", PANEL_API_KEY=setting("api_key"),
               DISCORD_TOKEN=setting("bot_token"))
    log = open(os.path.join(BASE, "bot.log"), "a")
    BOT["proc"] = subprocess.Popen([sys.executable, os.path.join(BASE, "bot.py")], env=env,
                                   stdout=log, stderr=log, cwd=BASE)


def bot_stop():
    if bot_running():
        BOT["proc"].terminate()
    BOT["proc"] = None


# ---------------------------------------------------------------- auth
@app.before_request
def load_user():
    g.me = None
    if session.get("uid"):
        g.me = db().execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
        if not g.me:
            session.clear()


@app.context_processor
def ctx():
    return {"pn": PANEL_NAME, "me": g.get("me")}


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.me:
            return redirect(url_for("login"))
        return f(*a, **k)
    return w


def admin_required(f):
    @wraps(f)
    @login_required
    def w(*a, **k):
        if not g.me["is_admin"]:
            abort(403)
        return f(*a, **k)
    return w


def my_vps(vid):
    v = db().execute("SELECT * FROM vps WHERE id=?", (vid,)).fetchone()
    if not v or (v["user_id"] != g.me["id"] and not g.me["is_admin"]):
        abort(404)
    return v


@app.route("/")
def index():
    return redirect(url_for("dashboard" if g.me else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = db().execute("SELECT * FROM users WHERE username=?",
                         (request.form["username"].strip().lower(),)).fetchone()
        if u and check_password_hash(u["pw"], request.form["password"]):
            session["uid"] = u["id"]
            return redirect(url_for("dashboard"))
        flash("Wrong username or password.")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u = request.form["username"].strip().lower()
        p = request.form["password"]
        if not re.fullmatch(r"[a-z0-9_]{3,20}", u) or len(p) < 6:
            flash("Username: 3-20 chars (a-z 0-9 _). Password: min 6 chars.")
        elif db().execute("SELECT 1 FROM users WHERE username=?", (u,)).fetchone():
            flash("Username already taken.")
        else:
            first = db().execute("SELECT COUNT(*) c FROM users").fetchone()["c"] == 0
            cur = db().execute("INSERT INTO users(username,pw,is_admin,created) VALUES(?,?,?,?)",
                               (u, generate_password_hash(p), 1 if first else 0, int(time.time())))
            db().commit()
            session["uid"] = cur.lastrowid
            return redirect(url_for("dashboard"))
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------- user panel
@app.route("/dashboard")
@login_required
def dashboard():
    rows = db().execute("SELECT * FROM vps WHERE user_id=? ORDER BY id DESC", (g.me["id"],)).fetchall()
    vs = [dict(r, up=(r["status"] == "ready" and not r["suspended"] and running(r["id"]))) for r in rows]
    return render_template("dashboard.html", vs=vs)


@app.route("/vps/<int:vid>")
@login_required
def vps_page(vid):
    v = my_vps(vid)
    return render_template("vps.html", v=v, up=running(vid))


@app.route("/vps/<int:vid>/<action>", methods=["POST"])
@login_required
def vps_action(vid, action):
    v = my_vps(vid)
    if v["suspended"] and not g.me["is_admin"]:
        flash("This VPS is suspended. Contact admin.")
    elif action == "start":
        sh(["docker", "start", cname(vid)], 60); flash("Started.")
    elif action == "stop":
        sh(["docker", "stop", "-t", "5", cname(vid)], 60); flash("Stopped.")
    elif action == "restart":
        sh(["docker", "restart", "-t", "5", cname(vid)], 60); flash("Restarted.")
    elif action == "reinstall":
        db().execute("UPDATE vps SET status='installing', sshx=NULL WHERE id=?", (vid,))
        db().commit()
        threading.Thread(target=provision, args=(vid,), daemon=True).start()
        flash("Reinstalling... wait a minute.")
    elif action == "sshx":
        name = cname(vid)
        sh(["docker", "exec", name, "sh", "-c", "pkill sshx 2>/dev/null; rm -f /tmp/sshx.log"], 15)
        sh(["docker", "exec", "-d", name, "sh", "-c",
            "curl -sSf https://sshx.io/get | sh -s run > /tmp/sshx.log 2>&1"], 15)
        link = None
        for _ in range(12):
            time.sleep(1.5)
            _, out = sh(["docker", "exec", name, "cat", "/tmp/sshx.log"], 10)
            m = re.search(r"https://sshx\.io/s/\S+", out)
            if m:
                link = re.sub(r"\x1b\[[0-9;]*m", "", m.group(0))
                break
        db().execute("UPDATE vps SET sshx=? WHERE id=?", (link, vid))
        db().commit()
        flash("SSHX link ready." if link else "SSHX failed (is the VPS running with internet?).")
    return redirect(url_for("vps_page", vid=vid))


@app.route("/vps/<int:vid>/exec", methods=["POST"])
@login_required
def vps_exec(vid):
    v = my_vps(vid)
    if v["suspended"] and not g.me["is_admin"]:
        return jsonify(out="VPS suspended.")
    cmd = (request.json or {}).get("cmd", "")
    shell = "sh" if v["os"] == "alpine" else "bash"
    _, out = sh(["docker", "exec", cname(vid), shell, "-lc", cmd], 60)
    return jsonify(out=out)


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        if not check_password_hash(g.me["pw"], request.form["old"]):
            flash("Old password is wrong.")
        elif len(request.form["new"]) < 6:
            flash("New password too short.")
        else:
            db().execute("UPDATE users SET pw=? WHERE id=?",
                         (generate_password_hash(request.form["new"]), g.me["id"]))
            db().commit()
            flash("Password changed.")
    n = db().execute("SELECT COUNT(*) c FROM vps WHERE user_id=?", (g.me["id"],)).fetchone()["c"]
    return render_template("profile.html", n=n)


# ---------------------------------------------------------------- admin panel
@app.route("/admin")
@admin_required
def admin():
    users = db().execute("SELECT * FROM users ORDER BY id").fetchall()
    vs = db().execute("SELECT vps.*, users.username un FROM vps JOIN users ON users.id=vps.user_id ORDER BY vps.id DESC").fetchall()
    stats = dict(users=len(users), vps=len(vs), ram=sum(v["ram"] for v in vs),
                 sus=sum(v["suspended"] for v in vs))
    badmins = [r["ident"] for r in db().execute("SELECT ident FROM bot_admins ORDER BY ident")]
    return render_template("admin.html", users=users, vs=vs, stats=stats, oses=list(OS_IMAGES),
                           owner=setting("owner_id"), has_token=bool(setting("bot_token")),
                           on=bot_running(), badmins=badmins)


@app.route("/admin/create", methods=["POST"])
@admin_required
def admin_create():
    u = db().execute("SELECT id FROM users WHERE username=?", (request.form["username"].strip().lower(),)).fetchone()
    if not u:
        flash("User not found.")
    else:
        try:
            vid, err = create_vps(u["id"], float(request.form["ram"]), float(request.form["cpu"]),
                                  float(request.form["disk"]), request.form["os"])
        except ValueError:
            vid, err = None, "Invalid numbers."
        flash(err or f"VPS #{vid} is being created.")
    return redirect(url_for("admin"))


@app.route("/admin/vps/<int:vid>/<action>", methods=["POST"])
@admin_required
def admin_vps(vid, action):
    if action == "delete":
        destroy_vps(vid); flash("VPS deleted.")
    elif action == "suspend":
        v = my_vps(vid)
        if v["suspended"]:
            db().execute("UPDATE vps SET suspended=0 WHERE id=?", (vid,)); flash("Unsuspended.")
        else:
            db().execute("UPDATE vps SET suspended=1 WHERE id=?", (vid,))
            sh(["docker", "stop", "-t", "3", cname(vid)], 30); flash("Suspended.")
        db().commit()
    return redirect(url_for("admin"))


@app.route("/admin/user/<int:uid>/<action>", methods=["POST"])
@admin_required
def admin_user(uid, action):
    if uid == g.me["id"]:
        flash("You can't do that to yourself.")
    elif action == "delete":
        for v in db().execute("SELECT id FROM vps WHERE user_id=?", (uid,)).fetchall():
            destroy_vps(v["id"])
        db().execute("DELETE FROM users WHERE id=?", (uid,)); db().commit(); flash("User deleted.")
    elif action == "toggle":
        db().execute("UPDATE users SET is_admin=1-is_admin WHERE id=?", (uid,)); db().commit()
    return redirect(url_for("admin"))


@app.route("/admin/bot", methods=["POST"])
@admin_required
def admin_bot():
    a = request.form["a"]
    if a == "save":
        if request.form.get("token"):
            set_setting("bot_token", request.form["token"].strip())
        set_setting("owner_id", request.form.get("owner", "").strip())
        flash("Bot settings saved.")
    elif a == "start":
        if not setting("bot_token"):
            flash("Save the Discord bot token first.")
        else:
            bot_stop(); bot_start(); flash("Bot started.")
    elif a == "stop":
        bot_stop(); flash("Bot stopped.")
    elif a == "addadmin":
        i = request.form.get("ident", "").strip().lower().strip("<@!>")
        if i:
            db().execute("INSERT OR IGNORE INTO bot_admins VALUES(?)", (i,)); db().commit()
            flash("Bot admin added.")
    elif a == "rmadmin":
        db().execute("DELETE FROM bot_admins WHERE ident=?", (request.form.get("ident", ""),)); db().commit()
        flash("Bot admin removed.")
    return redirect(url_for("admin") + "#bot")


@app.route("/admin/api", methods=["GET", "POST"])
@admin_required
def admin_api():
    if request.method == "POST":
        a = request.form["a"]
        if a == "regen":
            set_setting("api_key", "zn_" + secrets.token_hex(24)); flash("New API key generated. Restart the bot.")
        elif a == "save":
            if request.form.get("token"):
                set_setting("bot_token", request.form["token"].strip())
            set_setting("owner_id", request.form.get("owner", "").strip())
            flash("Saved.")
        elif a == "start":
            if not setting("bot_token"):
                flash("Save the Discord bot token first.")
            else:
                bot_start(); flash("Bot started.")
        elif a == "stop":
            bot_stop(); flash("Bot stopped.")
        return redirect(url_for("admin_api"))
    log = ""
    p = os.path.join(BASE, "bot.log")
    if os.path.exists(p):
        log = "".join(open(p).readlines()[-15:])
    return render_template("api.html", key=setting("api_key"), owner=setting("owner_id"),
                           has_token=bool(setting("bot_token")), on=bot_running(), log=log)


# ---------------------------------------------------------------- bot REST API
def api_guard(f):
    @wraps(f)
    def w(*a, **k):
        if request.headers.get("X-API-Key") != setting("api_key"):
            return jsonify(ok=False, error="Invalid API key."), 401
        return f(*a, **k)
    return w


def panel_user(name):
    return db().execute("SELECT * FROM users WHERE username=?", (str(name).strip().lower(),)).fetchone()


@app.route("/api/create", methods=["POST"])
@api_guard
def api_create():
    d = request.json or {}
    u = panel_user(d.get("username", ""))
    if not u:
        return jsonify(ok=False, error="Panel user not found.")
    try:
        vid, err = create_vps(u["id"], float(d["ram"]), float(d["cpu"]), float(d["disk"]), str(d["os"]))
    except (KeyError, ValueError):
        return jsonify(ok=False, error="Invalid values.")
    return jsonify(ok=not err, error=err, id=vid)


def pick(d):
    u = panel_user(d.get("username", ""))
    if not u:
        return None, "Panel user not found."
    rows = db().execute("SELECT * FROM vps WHERE user_id=?", (u["id"],)).fetchall()
    if d.get("id"):
        rows = [r for r in rows if str(r["id"]) == str(d["id"])]
    if not rows:
        return None, "No matching VPS for that user."
    if len(rows) > 1:
        return None, "User has several VPS - give the VPS id at the end. IDs: " + ", ".join(str(r["id"]) for r in rows)
    return rows[0], None


@app.route("/api/delete", methods=["POST"])
@api_guard
def api_delete():
    v, err = pick(request.json or {})
    if err:
        return jsonify(ok=False, error=err)
    destroy_vps(v["id"])
    return jsonify(ok=True)


@app.route("/api/suspend", methods=["POST"])
@api_guard
def api_suspend():
    v, err = pick(request.json or {})
    if err:
        return jsonify(ok=False, error=err)
    new = 0 if v["suspended"] else 1
    db().execute("UPDATE vps SET suspended=? WHERE id=?", (new, v["id"])); db().commit()
    if new:
        sh(["docker", "stop", "-t", "3", cname(v["id"])], 30)
    return jsonify(ok=True, suspended=bool(new))


@app.route("/api/admins", methods=["GET", "POST", "DELETE"])
@api_guard
def api_admins():
    if request.method in ("POST", "DELETE"):
        ident = str((request.json or {}).get("ident", "")).strip().lower()
        if ident:
            if request.method == "POST":
                db().execute("INSERT OR IGNORE INTO bot_admins VALUES(?)", (ident,))
            else:
                db().execute("DELETE FROM bot_admins WHERE ident=?", (ident,))
            db().commit()
    ids = [r["ident"] for r in db().execute("SELECT ident FROM bot_admins")]
    if setting("owner_id"):
        ids.append(setting("owner_id").lower())
    return jsonify(ok=True, admins=ids)


# ---------------------------------------------------------------- templates
CSS = """
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,sans-serif;color:#e9e6ff;min-height:100vh;
background:radial-gradient(1200px 600px at 10% -10%,#3b1d8f55,transparent),radial-gradient(900px 500px at 100% 0,#06b6d433,transparent),#0a0618}
a{color:#8be9fd;text-decoration:none}nav{display:flex;gap:18px;align-items:center;padding:14px 28px;background:#ffffff0a;
backdrop-filter:blur(14px);border-bottom:1px solid #ffffff14;position:sticky;top:0;z-index:5}
nav b{font-size:20px;background:linear-gradient(90deg,#a78bfa,#22d3ee);-webkit-background-clip:text;color:transparent;margin-right:auto}
main{max-width:1100px;margin:28px auto;padding:0 18px}.card{background:#ffffff0d;border:1px solid #ffffff1a;border-radius:18px;
padding:22px;backdrop-filter:blur(12px);box-shadow:0 10px 40px #0006;margin-bottom:20px}
h1,h2{margin:0 0 14px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px}
input,select{width:100%;padding:11px 14px;margin:6px 0 12px;border-radius:12px;border:1px solid #ffffff22;background:#0d0a22;color:#fff}
button,.btn{display:inline-block;border:0;cursor:pointer;padding:10px 18px;border-radius:12px;color:#fff;font-weight:600;
background:linear-gradient(135deg,#7c3aed,#06b6d4);transition:.2s}button:hover{transform:translateY(-2px);box-shadow:0 6px 20px #7c3aed66}
.red{background:linear-gradient(135deg,#ef4444,#be123c)}.gray{background:#ffffff1f}.flash{background:#7c3aed33;border:1px solid #7c3aed;
padding:12px 16px;border-radius:12px;margin-bottom:16px}.pill{padding:3px 12px;border-radius:99px;font-size:12px;font-weight:700}
.on{background:#16a34a44;color:#4ade80}.off{background:#ef444433;color:#f87171}.mid{background:#f59e0b33;color:#fbbf24}
table{width:100%;border-collapse:collapse}td,th{padding:10px;text-align:left;border-bottom:1px solid #ffffff14;font-size:14px}
form.i{display:inline}.big{font-size:34px;font-weight:800}.muted{color:#a9a3d6;font-size:13px}.row{display:flex;gap:10px;flex-wrap:wrap}
pre{background:#05030f;padding:14px;border-radius:12px;overflow:auto;max-height:320px;white-space:pre-wrap}
.auth{max-width:400px;margin:9vh auto}.logo{font-size:34px;font-weight:800;text-align:center;background:linear-gradient(90deg,#a78bfa,#22d3ee);
-webkit-background-clip:text;color:transparent}.sub{text-align:center;color:#a9a3d6;margin-bottom:20px}
"""

HEAD = """<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>{{pn}}</title><style>""" + CSS + """</style></head><body>
{% if me %}<nav><b>⚡ {{pn}}</b><a href="/dashboard">Dashboard</a><a href="/profile">Profile</a>
{% if me.is_admin %}<a href="/admin">Admin Panel</a><a href="/admin/api">API &amp; Bot</a>{% endif %}<a href="/logout">Logout</a></nav>{% endif %}
<main>{% for m in get_flashed_messages() %}<div class=flash>{{m}}</div>{% endfor %}"""
TAIL = "</main></body></html>"


def page(body):
    return HEAD + body + TAIL


T = {}
T["login.html"] = page("""<div class="auth card"><div class=logo>⚡ {{pn}}</div><div class=sub>Custom VPS Management Panel</div>
<form method=post>Username<input name=username required>Password<input name=password type=password required>
<button style="width:100%">Login</button></form><p class=muted style="text-align:center">No account? <a href="/register">Register</a></p></div>""")
T["register.html"] = page("""<div class="auth card"><div class=logo>⚡ {{pn}}</div><div class=sub>Create your account</div>
<form method=post>Username<input name=username required>Password<input name=password type=password required>
<button style="width:100%">Register</button></form><p class=muted style="text-align:center">Have an account? <a href="/login">Login</a></p></div>""")
T["dashboard.html"] = page("""<h1>My VPS</h1>{% if not vs %}<div class=card>No VPS yet. Ask an admin to create one for you.</div>{% endif %}
<div class=grid>{% for v in vs %}<div class=card><div class=row style="justify-content:space-between"><b>{{v.name}}</b>
{% if v.suspended %}<span class="pill off">SUSPENDED</span>{% elif v.status!='ready' %}<span class="pill mid">{{v.status|upper}}</span>
{% elif v.up %}<span class="pill on">ONLINE</span>{% else %}<span class="pill off">OFFLINE</span>{% endif %}</div>
<div class=big>{{ '%g'|format(v.ram) }} GB</div><div class=muted>RAM · {{v.os}}</div><br><a class=btn href="/vps/{{v.id}}">Manage</a></div>{% endfor %}</div>""")
T["vps.html"] = page("""<h1>{{v.name}} <span class="pill {{'on' if up else 'off'}}">{{'ONLINE' if up else 'OFFLINE'}}</span></h1>
<div class=card><div class=big>{{ '%g'|format(v.ram) }} GB RAM</div><div class=muted>{{v.cpu}} vCPU · {{v.disk|int}} GB disk · {{v.os}}</div>
{% if v.root_pw %}<p>Login: <code>root</code> / <code>{{v.root_pw}}</code></p>{% endif %}
<div class=row>{% for a in ['start','stop','restart','sshx'] %}<form class=i method=post action="/vps/{{v.id}}/{{a}}"><button class="{{'gray' if a=='stop'}}">{{a|upper}}</button></form>{% endfor %}
<form class=i method=post action="/vps/{{v.id}}/reinstall" onsubmit="return confirm('Wipe and reinstall?')"><button class=red>REINSTALL</button></form></div>
{% if v.sshx %}<p>SSHX: <a href="{{v.sshx}}" target=_blank>{{v.sshx}}</a></p>{% endif %}</div>
<div class=card><h2>Console</h2><pre id=o>Type a command below…</pre>
<input id=c placeholder="e.g. neofetch, apt update, free -m" autocomplete=off>
<script>const o=document.getElementById('o'),c=document.getElementById('c');c.addEventListener('keydown',async e=>{if(e.key!=='Enter')return;
const cmd=c.value;c.value='';o.textContent+='\\n$ '+cmd+'\\n';const r=await fetch('/vps/{{v.id}}/exec',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd})});
o.textContent+=(await r.json()).out;o.scrollTop=o.scrollHeight});</script></div>""")
T["profile.html"] = page("""<h1>Profile</h1><div class=card><p><b>{{me.username}}</b> {% if me.is_admin %}<span class="pill on">ADMIN</span>{% endif %}</p>
<p class=muted>{{n}} VPS</p></div><div class=card><h2>Change password</h2><form method=post>Old password<input name=old type=password required>
New password<input name=new type=password required><button>Update</button></form></div>""")
T["admin.html"] = page("""<h1>Admin Panel</h1><div class=grid>
<div class=card><div class=big>{{stats.users}}</div><div class=muted>Users</div></div><div class=card><div class=big>{{stats.vps}}</div><div class=muted>VPS</div></div>
<div class=card><div class=big>{{ '%g'|format(stats.ram) }} GB</div><div class=muted>RAM allocated</div></div><div class=card><div class=big>{{stats.sus}}</div><div class=muted>Suspended</div></div></div>
<div class=card><h2>Create VPS</h2><form method=post action="/admin/create" class=row>
<input name=username placeholder="panel username" required style="flex:2"><input name=ram placeholder="RAM GB" required style="flex:1"><input name=cpu placeholder="CPU" required style="flex:1">
<input name=disk placeholder="Disk GB" required style="flex:1"><select name=os style="flex:1">{% for o in oses %}<option>{{o}}</option>{% endfor %}</select><button>Create</button></form></div>
<div class=card><h2>All VPS</h2><table><tr><th>ID<th>User<th>RAM<th>CPU<th>Disk<th>OS<th>Status<th></tr>{% for v in vs %}<tr><td>{{v.id}}<td>{{v.un}}<td>{{ '%g'|format(v.ram) }}G<td>{{v.cpu}}<td>{{v.disk|int}}G<td>{{v.os}}
<td>{{'suspended' if v.suspended else v.status}}<td><a class=btn href="/vps/{{v.id}}">Bash</a>
<form class=i method=post action="/admin/vps/{{v.id}}/suspend"><button class=gray>{{'Unsuspend' if v.suspended else 'Suspend'}}</button></form>
<form class=i method=post action="/admin/vps/{{v.id}}/delete" onsubmit="return confirm('Delete VPS?')"><button class=red>Delete</button></form></tr>{% endfor %}</table></div>
<div class=card id=bot><h2>Discord Bot <span class="pill {{'on' if on else 'off'}}">{{'RUNNING' if on else 'STOPPED'}}</span></h2>
<form method=post action="/admin/bot"><input type=hidden name=a value=save>Bot token {% if has_token %}(saved ✓){% endif %}
<input name=token type=password placeholder="paste Discord bot token (leave empty to keep)">Owner Discord ID<input name=owner value="{{owner}}" placeholder="your Discord user ID"><button>Save</button></form>
<div class=row style="margin:14px 0"><form class=i method=post action="/admin/bot"><input type=hidden name=a value=start><button>{{'Restart' if on else 'Start'}} bot</button></form>
<form class=i method=post action="/admin/bot"><input type=hidden name=a value=stop><button class=red>Stop bot</button></form><a class="btn gray" href="/admin/api">API key &amp; log</a></div>
<b>Bot admins</b> <span class=muted>(can use free? commands)</span><form method=post action="/admin/bot" class=row style="margin-top:8px"><input type=hidden name=a value=addadmin>
<input name=ident placeholder="Discord ID or username" required style="flex:3"><button>Add admin</button></form>
<table>{% for b in badmins %}<tr><td>{{b}}<td><form class=i method=post action="/admin/bot"><input type=hidden name=a value=rmadmin><input type=hidden name=ident value="{{b}}"><button class=red>Remove</button></form></tr>{% endfor %}</table></div>
<div class=card><h2>Users</h2><table><tr><th>ID<th>Username<th>Role<th></tr>{% for u in users %}<tr><td>{{u.id}}<td>{{u.username}}<td>{{'admin' if u.is_admin else 'user'}}<td>
<form class=i method=post action="/admin/user/{{u.id}}/toggle"><button class=gray>Toggle admin</button></form>
<form class=i method=post action="/admin/user/{{u.id}}/delete" onsubmit="return confirm('Delete user and VPS?')"><button class=red>Delete</button></form></tr>{% endfor %}</table></div>""")
T["api.html"] = page("""<h1>API &amp; Discord Bot</h1><div class=card><h2>API key</h2><pre>{{key}}</pre>
<p class=muted>Bot sends this in the <code>X-API-Key</code> header. Panel URL: <code>http://localhost:{{request.host.split(':')[-1]}}</code></p>
<form method=post><input type=hidden name=a value=regen><button class=gray>Regenerate key</button></form></div>
<div class=card><h2>Bot settings</h2><form method=post><input type=hidden name=a value=save>Discord bot token {% if has_token %}(saved ✓){% endif %}
<input name=token type=password placeholder="paste token to set / change">Owner Discord ID (first bot admin)<input name=owner value="{{owner}}">
<button>Save</button></form></div><div class=card><h2>Bot status: <span class="pill {{'on' if on else 'off'}}">{{'RUNNING' if on else 'STOPPED'}}</span></h2>
<div class=row><form method=post><input type=hidden name=a value=start><button>Start bot</button></form>
<form method=post><input type=hidden name=a value=stop><button class=red>Stop bot</button></form></div><h2 style="margin-top:18px">Bot log</h2><pre>{{log or 'empty'}}</pre></div>""")

app.jinja_loader = DictLoader(T)

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=PORT, threaded=True)
