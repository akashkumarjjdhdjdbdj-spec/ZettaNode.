#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Install Python 3 first"; exit 1; }
if [ ! -f .env ]; then cp .env.example .env; python3 - <<'PY'
import secrets
p=".env"; s=open(p).read().replace("CHANGE_ME",secrets.token_urlsafe(48)); open(p,"w").write(s)
PY
fi
read -r -p "Panel name [ZettaNode Custom VPS Management Panel]: " n; n=${n:-ZettaNode Custom VPS Management Panel}
read -r -p "Panel port [8090]: " p; p=${p:-8090}
python3 - "$n" "$p" <<'PY'
import sys,re
f=".env"; s=open(f).read()
for k,v in [("PANEL_NAME",sys.argv[1]),("PANEL_PORT",sys.argv[2])]:
 s=re.sub(r"(?m)^"+k+r"=.*$",k+"="+v,s)
open(f,"w").write(s)
PY
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
mkdir -p data
chmod +x install.sh uninstall.sh
echo "Installed. Edit .env, then run: .venv/bin/python app.py"
echo "Panel: http://localhost:$p"
