# ZettaNode
Install on a host with Docker Engine access:
```bash
chmod +x install.sh uninstall.sh
./install.sh
nano .env
.venv/bin/python app.py
```
Register panel user accounts. First admin defaults to values in `.env`; change `BOOTSTRAP_ADMIN_PASSWORD` before production.

Generate API key from Admin page. Configure `.env`:
```
DISCORD_TOKEN=your-token
PANEL_API_URL=http://127.0.0.1:8090
PANEL_API_KEY=zn_your-generated-key
BOT_ADMIN_IDS=discord_user_id
```
Run bot: `.venv/bin/python bot.py`

Bot commands:
- `free?create 4 2 80 ubuntu panelusername`
- `free?vps-delete panelusername VPS_UUID`
- `free?vps-suspend panelusername VPS_UUID`
- `free?add-admin DISCORD_USER_ID`
- `free?remove-admin DISCORD_USER_ID`

API:
- `POST /api/v1/vps` JSON: `panel_username`, `ram_gb`, `cpu`, `disk_gb`, `os`
- `GET /api/v1/vps`
- `POST /api/v1/vps/{id}/start|stop|restart|suspend|unsuspend`
- `DELETE /api/v1/vps/{id}/delete`
- `GET /api/v1/vps/{id}/stats`
All API requests require `X-API-Key`.

IMPORTANT:
- MAX_VPS_RAM_GB is set to 200. This is a maximum per VPS, not physical RAM magically provided by Railway. The Docker host must actually have sufficient RAM.
- Railway's normal app container does not automatically expose a Docker daemon/socket or privileged sibling-container support. This panel needs a reachable Docker Engine host. If Railway does not provide that access in your deployment, host Docker workloads on a separate machine and connect through a secured private Docker API.
- Docker containers are not full hardware VMs. Disk quota requires Docker host/filesystem support; this build asks Docker to apply storage-opt and reports failure if unsupported.
- Web console/SSHX and reinstall are not included in this initial safe build.
- Never expose `/var/run/docker.sock` publicly. Use HTTPS, firewall and strong credentials.
