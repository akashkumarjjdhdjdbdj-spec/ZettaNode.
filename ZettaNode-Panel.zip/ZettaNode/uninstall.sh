#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "This removes only the Python virtualenv. It preserves .env, database, source and all Docker containers."
read -r -p "Continue? [y/N] " a
if [[ "$a" =~ ^[Yy]$ ]]; then rm -rf .venv; echo "Virtualenv removed; VPS containers/data preserved."; else echo "Cancelled."; fi
