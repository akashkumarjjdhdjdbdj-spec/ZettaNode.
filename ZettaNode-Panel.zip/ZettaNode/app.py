import os, re, sqlite3, secrets, hashlib, hmac, uuid
from functools import wraps
from flask import Flask,request,redirect,url_for,session,flash,jsonify,render_template,abort
from dotenv import load_dotenv
from docker_manager import DockerManager
load_dotenv()
app=Flask(__name__); app.secret_key=os.getenv("SECRET_KEY","replace-this")
DB=os.getenv("DATABASE_PATH","./data/zettanode.db"); os.makedirs(os.path.dirname(DB) or ".",exist_ok=True)
PANEL=os.getenv("PANEL_NAME","ZettaNode Custom VPS Management Panel")
MAX_RAM=int(os.getenv("MAX_VPS_RAM_GB","200")); MAX_CPU=int(os.getenv("MAX_VPS_CPU","64")); MAX_DISK=int(os.getenv("MAX_VPS_DISK_GB","1000"))
try: docker_mgr=DockerManager(); DOCKER_ERROR=None
except Exception as e: docker_mgr=None; DOCKER_ERROR=str(e)

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def hashpw(p,s=None):
    s=s or secrets.token_hex(16)
    return s+"$"+hashlib.pbkdf2_hmac("sha256",p.encode(),s.encode(),240000).hex()
def checkpw(p,h):
    try:
        s,d=h.split("$",1)
        return hmac.compare_digest(d,hashlib.pbkdf2_hmac("sha256",p.encode(),s.encode(),240000).hex())
    except: return False
def init():
    with conn() as c:
        c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT DEFAULT 'user');
        CREATE TABLE IF NOT EXISTS vps(id TEXT PRIMARY KEY,owner_id INTEGER,panel_username TEXT,docker_id TEXT,name TEXT,ram_gb INTEGER,cpu INTEGER,disk_gb INTEGER,os TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS api_keys(id INTEGER PRIMARY KEY,label TEXT,key_hash TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP);""")
        if not c.execute("SELECT id FROM users WHERE role='admin'").fetchone():
            c.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES(?,?,?)",(os.getenv("BOOTSTRAP_ADMIN_USERNAME","admin"),hashpw(os.getenv("BOOTSTRAP_ADMIN_PASSWORD","ChangeThisPassword123!")),"admin"))
init()
def user():
    if not session.get("uid"): return None
    with conn() as c: return c.execute("SELECT * FROM users WHERE id=?",(session["uid"],)).fetchone()
def logged(f):
    @wraps(f)
    def w(*a,**k):
        if not user(): return redirect(url_for("login"))
        return f(*a,**k)
    return w
def admin(f):
    @wraps(f)
    def w(*a,**k):
        u=user()
        if not u or u["role"]!="admin": abort(403)
        return f(*a,**k)
    return w
def api_auth(f):
    @wraps(f)
    def w(*a,**k):
        key=request.headers.get("X-API-Key","")
        digest=hashlib.sha256(key.encode()).hexdigest()
        with conn() as c: found=c.execute("SELECT id FROM api_keys WHERE key_hash=?",(digest,)).fetchone()
        if not found: return jsonify(error="Invalid API key"),401
        return f(*a,**k)
    return w
@app.after_request
def secure(r):
    r.headers["X-Content-Type-Options"]="nosniff"; r.headers["X-Frame-Options"]="SAMEORIGIN"
    r.headers["Referrer-Policy"]="strict-origin-when-cross-origin"; return r
@app.route("/")
def home(): return redirect(url_for("dashboard" if user() else "login"))
@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        un=request.form.get("username","").strip(); pw=request.form.get("password","")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}",un) or len(pw)<10: flash("Username 3-32 chars; password minimum 10 characters.")
        else:
            try:
                with conn() as c: c.execute("INSERT INTO users(username,password) VALUES(?,?)",(un,hashpw(pw)))
                flash("Registered. Please login."); return redirect(url_for("login"))
            except sqlite3.IntegrityError: flash("Username already exists.")
    return render_template("auth.html",mode="Register",panel=PANEL)
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        with conn() as c: u=c.execute("SELECT * FROM users WHERE username=?",(request.form.get("username",""),)).fetchone()
        if u and checkpw(request.form.get("password",""),u["password"]): session.clear(); session["uid"]=u["id"]; return redirect(url_for("dashboard"))
        flash("Invalid login.")
    return render_template("auth.html",mode="Login",panel=PANEL)
@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))
@app.route("/dashboard")
@logged
def dashboard():
    u=user()
    with conn() as c:
        rows=c.execute("SELECT v.*,u.username owner FROM vps v JOIN users u ON u.id=v.owner_id "+("" if u["role"]=="admin" else "WHERE owner_id=?")+" ORDER BY created_at DESC",(() if u["role"]=="admin" else (u["id"],))).fetchall()
    items=[]
    for row in rows:
        d=dict(row); d["live"]={}
        if docker_mgr:
            try: d["live"]=docker_mgr.stats(row["docker_id"])
            except Exception as e: d["live"]={"status":"unknown","error":str(e)}
        items.append(d)
    return render_template("dashboard.html",panel=PANEL,user=u,vps=items,docker_error=DOCKER_ERROR)
@app.route("/admin")
@logged
@admin
def admin_page():
    with conn() as c:
        users=c.execute("SELECT id,username,role FROM users ORDER BY id").fetchall()
        keys=c.execute("SELECT label,created_at FROM api_keys ORDER BY id DESC").fetchall()
    return render_template("admin.html",panel=PANEL,user=user(),users=users,keys=keys)
@app.route("/admin/key",methods=["POST"])
@logged
@admin
def create_key():
    key="zn_"+secrets.token_urlsafe(36)
    with conn() as c: c.execute("INSERT INTO api_keys(label,key_hash) VALUES(?,?)",(request.form.get("label","Discord bot"),hashlib.sha256(key.encode()).hexdigest()))
    flash("Copy API key now (shown once): "+key); return redirect(url_for("admin_page"))
@app.route("/admin/role/<int:uid>",methods=["POST"])
@logged
@admin
def set_role(uid):
    role=request.form.get("role")
    if role not in ("admin","user"): abort(400)
    with conn() as c: c.execute("UPDATE users SET role=? WHERE id=?",(role,uid))
    return redirect(url_for("admin_page"))
@app.route("/vps/<vid>/<action>",methods=["POST"])
@logged
def action(vid,action):
    u=user()
    with conn() as c: v=c.execute("SELECT * FROM vps WHERE id=?",(vid,)).fetchone()
    if not v or (u["role"]!="admin" and v["owner_id"]!=u["id"]): abort(404)
    try:
        if not docker_mgr: raise RuntimeError(DOCKER_ERROR or "Docker unavailable")
        if action=="delete":
            docker_mgr.action(v["docker_id"],"delete")
            with conn() as c: c.execute("DELETE FROM vps WHERE id=?",(vid,))
        elif action in ("start","stop","restart","suspend","unsuspend"): docker_mgr.action(v["docker_id"],action)
        else: abort(400)
        flash("Action completed.")
    except Exception as e: flash("Action failed: "+str(e))
    return redirect(url_for("dashboard"))
@app.route("/api/v1/vps",methods=["GET","POST"])
@api_auth
def api_vps():
    if request.method=="GET":
        with conn() as c: rows=c.execute("SELECT id,panel_username,name,ram_gb,cpu,disk_gb,os FROM vps").fetchall()
        return jsonify(vps=[dict(x) for x in rows])
    if not docker_mgr: return jsonify(error="Docker unavailable",detail=DOCKER_ERROR),503
    try:
        d=request.get_json(force=True); un=str(d["panel_username"]).strip()
        ram=int(d["ram_gb"]); cpu=int(d["cpu"]); disk=int(d["disk_gb"]); osname=str(d.get("os","ubuntu")).lower()
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}",un): raise ValueError("Invalid panel_username")
        if not (1<=ram<=MAX_RAM and 1<=cpu<=MAX_CPU and 1<=disk<=MAX_DISK): raise ValueError(f"Allowed RAM 1-{MAX_RAM} GB, CPU 1-{MAX_CPU}, disk 1-{MAX_DISK} GB")
        with conn() as c: owner=c.execute("SELECT * FROM users WHERE username=?",(un,)).fetchone()
        if not owner: return jsonify(error="Panel user must register first"),404
        vid=str(uuid.uuid4()); name="zn-"+vid[:12]
        container=docker_mgr.create(name,ram,cpu,disk,osname)
        with conn() as c: c.execute("INSERT INTO vps(id,owner_id,panel_username,docker_id,name,ram_gb,cpu,disk_gb,os) VALUES(?,?,?,?,?,?,?,?,?)",(vid,owner["id"],un,container.id,name,ram,cpu,disk,osname))
        return jsonify(id=vid,name=name,panel_username=un,ram_gb=ram,cpu=cpu,disk_gb=disk,os=osname),201
    except Exception as e: return jsonify(error=str(e)),400
@app.route("/api/v1/vps/<vid>/<action>",methods=["POST","DELETE"])
@api_auth
def api_action(vid,action):
    with conn() as c: v=c.execute("SELECT * FROM vps WHERE id=?",(vid,)).fetchone()
    if not v: return jsonify(error="VPS not found"),404
    try:
        if action=="delete":
            docker_mgr.action(v["docker_id"],"delete")
            with conn() as c: c.execute("DELETE FROM vps WHERE id=?",(vid,))
        elif action in ("start","stop","restart","suspend","unsuspend"): docker_mgr.action(v["docker_id"],action)
        else: return jsonify(error="Unknown action"),400
        return jsonify(ok=True)
    except Exception as e: return jsonify(error=str(e)),400
@app.route("/api/v1/vps/<vid>/stats")
@api_auth
def api_stats(vid):
    with conn() as c: v=c.execute("SELECT * FROM vps WHERE id=?",(vid,)).fetchone()
    if not v: return jsonify(error="Not found"),404
    try: return jsonify(configured={"ram_gb":v["ram_gb"],"cpu":v["cpu"],"disk_gb":v["disk_gb"]},live=docker_mgr.stats(v["docker_id"]))
    except Exception as e: return jsonify(error=str(e)),400
if __name__=="__main__": app.run(host=os.getenv("PANEL_HOST","0.0.0.0"),port=int(os.getenv("PANEL_PORT","8090")))
