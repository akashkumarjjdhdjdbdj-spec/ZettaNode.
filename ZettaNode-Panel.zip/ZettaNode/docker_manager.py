import os
import docker
from docker.errors import APIError

IMAGES = {"ubuntu":"ubuntu:22.04", "debian":"debian:12", "alpine":"alpine:3.20"}

class DockerManager:
    def __init__(self):
        self.client = docker.DockerClient(base_url=os.getenv("DOCKER_HOST","unix:///var/run/docker.sock"))
        self.client.ping()

    def create(self, name, ram_gb, cpu, disk_gb, os_name):
        image = IMAGES.get(os_name.lower())
        if not image:
            raise ValueError("Supported OS: ubuntu, debian, alpine")
        self.client.images.pull(image)
        try:
            c = self.client.containers.create(
                image=image, name=name, hostname=name,
                command="sh -c 'while true; do sleep 3600; done'",
                detach=True, tty=True, stdin_open=True,
                mem_limit=f"{ram_gb}g", nano_cpus=int(cpu)*1_000_000_000,
                storage_opt={"size":f"{disk_gb}G"},
                labels={"zettanode.managed":"true"},
                restart_policy={"Name":"unless-stopped"}
            )
        except APIError as e:
            if "storage" in str(e).lower() or "size" in str(e).lower():
                raise RuntimeError("Docker host does not support per-container disk quotas. Configure filesystem quota support; creation stopped to avoid fake disk limits.") from e
            raise
        c.start()
        return c

    def get(self, cid):
        return self.client.containers.get(cid)

    def action(self, cid, action):
        c=self.get(cid)
        if action=="start": c.start()
        elif action=="stop": c.stop(timeout=10)
        elif action=="restart": c.restart(timeout=10)
        elif action=="suspend": c.pause()
        elif action=="unsuspend": c.unpause()
        elif action=="delete": c.remove(force=True)
        else: raise ValueError("Unknown action")
        return c

    def stats(self,cid):
        c=self.get(cid); c.reload()
        s=c.stats(stream=False); m=s.get("memory_stats",{})
        cs=s.get("cpu_stats",{}); ps=s.get("precpu_stats",{})
        cd=cs.get("cpu_usage",{}).get("total_usage",0)-ps.get("cpu_usage",{}).get("total_usage",0)
        sd=cs.get("system_cpu_usage",0)-ps.get("system_cpu_usage",0)
        n=cs.get("online_cpus",1)
        pct=(cd/sd*n*100) if sd>0 else 0
        return {"status":c.status,"ram_used_bytes":m.get("usage",0),"ram_limit_bytes":m.get("limit",0),"cpu_percent":round(pct,2)}
