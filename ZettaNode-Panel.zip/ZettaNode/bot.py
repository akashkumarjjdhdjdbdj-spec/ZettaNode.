import os, discord, aiohttp
from discord.ext import commands
from dotenv import load_dotenv
load_dotenv()
TOKEN=os.getenv("DISCORD_TOKEN",""); PREFIX=os.getenv("BOT_PREFIX","free?")
API=os.getenv("PANEL_API_URL","http://127.0.0.1:8090").rstrip("/")
KEY=os.getenv("PANEL_API_KEY","")
ADMINS={x.strip() for x in os.getenv("BOT_ADMIN_IDS","").split(",") if x.strip()}
intents=discord.Intents.default(); intents.message_content=True
bot=commands.Bot(command_prefix=PREFIX,intents=intents,help_command=None)
def is_admin(ctx): return str(ctx.author.id) in ADMINS
async def call(method,path,data=None):
 async with aiohttp.ClientSession() as s:
  async with s.request(method,API+path,json=data,headers={"X-API-Key":KEY},timeout=180) as r:
   try: return r.status,await r.json()
   except: return r.status,{"error":await r.text()}
@bot.event
async def on_ready(): print("ZettaNode bot online",bot.user)
@bot.command(name="create")
async def create(ctx,ram:int,cpu:int,disk:int,osname:str,panel_username:str):
 if not is_admin(ctx): return await ctx.reply("Not authorized.")
 status,d=await call("POST","/api/v1/vps",{"ram_gb":ram,"cpu":cpu,"disk_gb":disk,"os":osname,"panel_username":panel_username})
 if status==201: await ctx.reply(f"VPS created. Panel user: {panel_username} | RAM {ram}GB | CPU {cpu} | Disk {disk}GB | ID `{d['id']}`")
 else: await ctx.reply("VPS create failed: "+str(d.get("error","Unknown error")))
@bot.command(name="vps-delete")
async def delete(ctx,panel_username:str,vps_id:str):
 if not is_admin(ctx): return await ctx.reply("Not authorized.")
 status,d=await call("DELETE",f"/api/v1/vps/{vps_id}/delete")
 await ctx.reply("VPS deleted." if status==200 else "Delete failed: "+str(d.get("error")))
@bot.command(name="vps-suspend")
async def suspend(ctx,panel_username:str,vps_id:str):
 if not is_admin(ctx): return await ctx.reply("Not authorized.")
 status,d=await call("POST",f"/api/v1/vps/{vps_id}/suspend")
 await ctx.reply("VPS suspended." if status==200 else "Suspend failed: "+str(d.get("error")))
@bot.command(name="add-admin")
async def add_admin(ctx,discord_id:str):
 if not is_admin(ctx): return await ctx.reply("Not authorized.")
 await ctx.reply(f"Add {discord_id} to BOT_ADMIN_IDS in .env and restart bot to persist.")
@bot.command(name="remove-admin")
async def remove_admin(ctx,discord_id:str):
 if not is_admin(ctx): return await ctx.reply("Not authorized.")
 await ctx.reply(f"Remove {discord_id} from BOT_ADMIN_IDS in .env and restart bot to persist.")
if __name__=="__main__":
 if not TOKEN or not KEY: raise SystemExit("Set DISCORD_TOKEN and PANEL_API_KEY in .env")
 bot.run(TOKEN)
